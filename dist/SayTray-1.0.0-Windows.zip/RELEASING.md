﻿# Releasing SayTray (Windows)

For Jon: cut a shareable zip and upload it next to the macOS build.

## 1. Bump version

Edit `VERSION` (e.g. `1.0.1`). `install.ps1` stamps `saytray/_version.py` and the Add/Remove Programs entry from it.

## 2. Sanity check

```powershell
.\run_tests.ps1
.\install.ps1 -NoLaunch   # or full install
# Smoke: tray icon, About shows version, read a selection, hold dictate briefly
```

## 3. Package

```powershell
.\package_release.ps1
# → dist\SayTray-<VERSION>-Windows.zip
```

The zip is source + Install.cmd (no venv/voices). Recipients run Install.cmd once.

## 4. Upload

Attach the zip to the same **GitHub Release** as the macOS build (`SayTray-1.0.0-macOS.zip` + `SayTray-1.0.0-Windows.zip`).

## 5. Updating after ship

1. Change code / bump `VERSION`.
2. `.\package_release.ps1`
3. New GitHub Release with the new zip.
4. Users re-run Install.cmd; voices/settings stay in `%LOCALAPPDATA%\SayTray`.
