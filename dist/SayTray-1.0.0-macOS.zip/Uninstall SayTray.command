#!/bin/bash
cd "$(dirname "$0")"
bash ./uninstall.sh
read -r -p "Press Return to close…" _
